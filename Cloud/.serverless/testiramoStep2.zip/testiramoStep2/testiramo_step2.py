import json
import boto3
from utility.utils import create_response


def testiramo_step2(event, contenxt):
    print("uspheh")
    print(event)